
/* Js Custom files */

/* Global Variables of path */

var url_path = window.location.origin+'/pkdbbeta/';

if($("#addjobform").length > 0){
	function get_jobTypes(obj){
		var dep	=	$(obj).val();
		var tablename="`job_type`";
		var fieldname="id,title";
		var condition="`dep_id`";
		var id = dep;
		//var param = tablename +'/'+ fieldname +'/'+ condition  +'/'+ id;
		url = url_path + 'admin/jobs/get_result';
				
				//alert(dep);
				//alert(url);
				//$("#job_type").html("Pleaase Wait Loading...");
				
				$.ajax({
						type: "POST",
						url: url,
						data: {
							'tablename': tablename,
							'fieldname': fieldname,
							'condition': condition,
							'id': dep
							},
						
						success: function(data) {
							var object = JSON.parse(data);
							
							//console.log(data);
							//alert('success');
							//var html ='';
							//for(var i=0; i < object.types ; i++ ){
								//html +='<option value="'+ object.types[i]["id"]+'"> '+ object.types[i]["title"]+' </option>';
							//}
							$("#job_type").html(object);
							console.log(object);
						},
						error: function(data) {
							alert("Fail");
						}
				});
				//$.post( "jobtypes.php", { dep: dep},
		   // function( data ) {
						//$("#job_type").html(data);		
				 // });
	}
}  /// end of function get job types

if($("#adddepform").length > 0){
	function get_email(obj){
		
		var dep	=	$(obj).val();
		//alert(dep);
		var tablename="`employee`";
		var fieldname="emp_id,email";
		var condition="`emp_id`";
		var id = dep;
		//var param = tablename +'/'+ fieldname +'/'+ condition  +'/'+ id;
		url = url_path + 'admin/main/get_result';
				
				//alert(dep);
				//alert(url);
				//$("#job_type").html("Pleaase Wait Loading...");
				
				$.ajax({
						type: "POST",
						url: url,
						data: {
							'tablename': tablename,
							'fieldname': fieldname,
							'condition': condition,
							'id': dep
							},
						
						success: function(data) {
							var object = JSON.parse(data);
							$("#dept_email").html(object);
							console.log(object);
						},
						error: function(data) {
							alert("Fail");
						}
				});
				
	}
}  /// end of function get email

function deletefile(obj , file){
	//alert(file);
		var agree = confirm("Are You Sure to delete a file !");
		if(agree){
			var pass = "viral5678_";
			var getpass = prompt("Enter password");
			if(getpass == pass){
				var tablename="`upload`";
				var condition="`id`=" + obj;
				//var filename = file;
				url = url_path + 'admin/delete/deletefile';
				$.ajax({
						type: "POST",
						url: url,
						data: {
							'tablename': tablename,
							'condition': condition,
							'filename': file
							},
						
						success: function(data) {
							console.log(data);
							alert("Success! File Deleted");
							var html = '';
							html +="<div class='alert alert-success alert-dismissible'>";
							html +="<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>";
						    html +="File Deleted Successfully</div>";
							$("#delete").html(html);
							location.reload();
							
						},
						error: function(data) {
							alert("Failed! File Not Deleted");
							var html = '';
							html +="<div class='alert alert-success alert-dismissible'>";
							html +="<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>";
						    html +="File Not Deleted Successfully</div>";
							$("#delete").html(html);
							location.reload();
						}
				});
			} else {
					alert("OOPS! Wrong Password ! Try again!!!");	
			}
		} else{
			return false;
		}
		
}  //// end of function delete

function deletedept(obj){
	//alert(obj);
		var agree = confirm("Are You Sure to delete a department !");
		if(agree){
			var pass = "viral5678_";
			var getpass = prompt("Enter password");
			if(getpass == pass){
				var tablename="`department`";
				var condition="`dep_id`=" + obj;
				//var filename = file;
				url = url_path + 'admin/delete/';
				$.ajax({
						type: "POST",
						url: url,
						data: {
							'tablename': tablename,
							'condition': condition
							},
						
						success: function(data) {
							console.log(data);
							alert("Success!Department Deleted");
							var html = '';
							html +="<div class='alert alert-success alert-dismissible'>";
							html +="<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>";
						    html +="Department Deleted Successfully</div>";
							$("#delete").html(html);
							location.reload();
							
						},
						error: function(data) {
							alert("Failed! Department Not Deleted");
							var html = '';
							html +="<div class='alert alert-success alert-dismissible'>";
							html +="<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>";
						    html +="Department Not Deleted Successfully</div>";
							$("#delete").html(html);
							location.reload();
						}
				});
			} else {
					alert("OOPS! Wrong Password ! Try again!!!");	
			}
		} else{
			return false;
		}
		
}  //// end of function delete dept

function deletejobtype(obj){
	//alert(obj);
		var agree = confirm("Are You Sure to delete a job Type !");
		if(agree){
			var pass = "viral5678_";
			var getpass = prompt("Enter password");
			if(getpass == pass){
				var tablename="`job_type`";
				var condition="`id`=" + obj;
				//var filename = file;
				url = url_path + 'admin/delete/';
				$.ajax({
						type: "POST",
						url: url,
						data: {
							'tablename': tablename,
							'condition': condition
							},
						
						success: function(data) {
							console.log(data);
							alert("Success!Job type  Deleted");
							var html = '';
							html +="<div class='alert alert-success alert-dismissible'>";
							html +="<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>";
						    html +="Job Type Deleted Successfully</div>";
							$("#delete").html(html);
							location.reload();
							
						},
						error: function(data) {
							alert("Failed! Job Type Not Deleted");
							var html = '';
							html +="<div class='alert alert-success alert-dismissible'>";
							html +="<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>";
						    html +="Job type Not Deleted Successfully</div>";
							$("#delete").html(html);
							location.reload();
						}
				});
			} else {
					alert("OOPS! Wrong Password ! Try again!!!");	
			}
		} else{
			return false;
		}
		
}  //// end of function delete dept

function deletecdept(obj){
	//alert(obj);
		var agree = confirm("Are You Sure to delete a department !");
		if(agree){
			var pass = "viral5678_";
			var getpass = prompt("Enter password");
			if(getpass == pass){
				var tablename="`client_departments`";
				var condition="`cdep_id`=" + obj;
				//var filename = file;
				url = url_path + 'admin/delete/';
				$.ajax({
						type: "POST",
						url: url,
						data: {
							'tablename': tablename,
							'condition': condition
							},
						
						success: function(data) {
							console.log(data);
							alert("Success!Client Department Deleted");
							var html = '';
							html +="<div class='alert alert-success alert-dismissible'>";
							html +="<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>";
						    html +="Client Department Deleted Successfully</div>";
							$("#delete").html(html);
							location.reload();
							
						},
						error: function(data) {
							alert("Failed!Client Department Not Deleted");
							var html = '';
							html +="<div class='alert alert-success alert-dismissible'>";
							html +="<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>";
						    html +="Client Department Not Deleted Successfully</div>";
							$("#delete").html(html);
							location.reload();
						}
				});
			} else {
					alert("OOPS! Wrong Password ! Try again!!!");	
			}
		} else{
			return false;
		}
		
}  //// end of function delete dept